# Panduan Mengubah Web App menjadi APK Android

Berikut adalah langkah-langkah untuk mengubah aplikasi web Pelacak Lokasi menjadi aplikasi Android (APK).

## Metode 1: PWA to APK (Disarankan)

### Langkah 1: Deploy Aplikasi Web (PWA)
1. Deploy aplikasi web Anda ke domain publik (misalnya menggunakan Vercel, Netlify, atau Replit)
2. Pastikan aplikasi berhasil di-deploy dan dapat diakses secara publik

### Langkah 2: Konversi PWA ke APK
1. Kunjungi situs [PWA2APK](https://www.pwa2apk.com/) atau [Bubblewrap](https://github.com/GoogleChromeLabs/bubblewrap) 
2. Masukkan URL aplikasi web Anda yang telah di-deploy
3. Sesuaikan pengaturan aplikasi:
   - Nama aplikasi: "Aplikasi Pelacakan Lokasi"
   - Warna tema: #4f46e5
   - Versi aplikasi: 1.0.0
4. Klik tombol "Generate APK" dan ikuti instruksi selanjutnya
5. Unduh file APK yang dihasilkan

### Langkah 3: Install APK
1. Transfer file APK ke perangkat Android Anda
2. Buka file APK di perangkat Android
3. Izinkan instalasi dari sumber yang tidak dikenal jika diminta
4. Ikuti langkah-langkah instalasi

## Metode 2: WebView APK (Alternatif)

Alternatif lain adalah membuat aplikasi Android sederhana yang menggunakan WebView untuk menampilkan aplikasi web Anda.

### Langkah 1: Setup Android Studio
1. Unduh dan instal [Android Studio](https://developer.android.com/studio)
2. Buat proyek baru dengan "Empty Activity"

### Langkah 2: Modifikasi Layout
1. Buka file `activity_main.xml`
2. Ganti dengan kode berikut:
```xml
<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".MainActivity">

    <WebView
        android:id="@+id/webView"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />

</RelativeLayout>
```

### Langkah 3: Modifikasi MainActivity
1. Buka file `MainActivity.java` atau `MainActivity.kt`
2. Ganti dengan kode berikut (untuk Java):
```java
package com.example.lokasitracker;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setGeolocationEnabled(true);

        webView.setWebViewClient(new WebViewClient());
        // Ganti URL dengan URL aplikasi web Anda
        webView.loadUrl("https://url-aplikasi-anda.replit.app");
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
```

### Langkah 4: Tambahkan Izin
1. Buka file `AndroidManifest.xml`
2. Tambahkan izin berikut:
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

### Langkah 5: Build dan Export APK
1. Klik menu "Build" -> "Build Bundle(s) / APK(s)" -> "Build APK(s)"
2. Tunggu proses build selesai
3. Klik "locate" untuk menemukan file APK yang dihasilkan
4. Transfer dan instal APK di perangkat Android Anda

## Catatan Penting
- Pastikan aplikasi web Anda sudah dibuat sebagai PWA dengan service worker dan manifest.json
- Untuk penggunaan geolokasi, pastikan aplikasi meminta izin lokasi di browser dan di Android
- Untuk penggunaan offline, pastikan service worker Anda telah di-setup dengan benar untuk menyimpan cache