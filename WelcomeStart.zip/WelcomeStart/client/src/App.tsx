import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import { ProtectedRoute } from "./lib/protected-route";
import ErrorOverlay from "./components/error-overlay";
import { useState } from "react";
import { AuthProvider } from "./hooks/use-auth";

// Shared error context
export type ErrorState = {
  visible: boolean;
  title: string;
  message: string;
};

export type ErrorContextType = {
  error: ErrorState;
  showError: (title: string, message: string) => void;
  hideError: () => void;
};

function Router() {
  const [error, setError] = useState<ErrorState>({
    visible: false,
    title: "",
    message: ""
  });

  const showError = (title: string, message: string) => {
    setError({
      visible: true,
      title,
      message
    });
  };

  const hideError = () => {
    setError({
      ...error,
      visible: false
    });
  };

  const errorContext: ErrorContextType = {
    error,
    showError,
    hideError
  };

  return (
    <>
      <Switch>
        <ProtectedRoute path="/" component={() => <DashboardPage errorContext={errorContext} />} />
        <Route path="/auth">
          <AuthPage errorContext={errorContext} />
        </Route>
        <Route component={NotFound} />
      </Switch>
      {error.visible && (
        <ErrorOverlay 
          title={error.title} 
          message={error.message} 
          onDismiss={hideError} 
          onRetry={hideError} 
        />
      )}
    </>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router />
      <Toaster />
    </AuthProvider>
  );
}

export default App;
