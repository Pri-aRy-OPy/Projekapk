import { useAuth } from "@/hooks/use-auth";
import { LogOut, MapPin } from "lucide-react";
import StatusCard from "@/components/status-card";
import LocationMap from "@/components/location-map";
import LocationHistory from "@/components/location-history";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Location, Settings } from "@shared/schema";
import { useLocationService } from "@/lib/location-service";
import { Button } from "@/components/ui/button";
import { ErrorContextType } from "@/App";

export default function DashboardPage({ errorContext }: { errorContext: ErrorContextType }) {
  const { user, logoutMutation } = useAuth();
  const { startTracking, stopTracking, getCurrentLocation } = useLocationService();
  const [activeTab, setActiveTab] = useState<string>("map");

  // Get tracking settings
  const { 
    data: settings,
    isLoading: isLoadingSettings
  } = useQuery<Settings>({
    queryKey: [`/api/settings`],
  });

  // Get current location
  const { 
    data: currentLocation,
    isLoading: isLoadingLocation,
    error: locationError,
    refetch: refetchLocation
  } = useQuery<Location>({
    queryKey: [`/api/location/current`],
    refetchInterval: settings?.isTracking ? (settings?.trackingInterval * 1000) : false,
  });

  // Get location history
  const { 
    data: locationHistory,
    isLoading: isLoadingHistory,
    refetch: refetchHistory
  } = useQuery<Location[]>({
    queryKey: [`/api/location/history`],
  });

  // Handle location tracking errors
  useEffect(() => {
    if (locationError) {
      errorContext.showError(
        "Location Error",
        "Failed to get your current location. Please check permissions and try again."
      );
    }
  }, [locationError, errorContext]);

  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Handle refresh location
  const handleRefreshLocation = async () => {
    try {
      const location = await getCurrentLocation();
      if (location) {
        refetchLocation();
        refetchHistory();
      }
    } catch (error) {
      errorContext.showError(
        "Location Error",
        "Failed to refresh your current location. Please try again."
      );
    }
  };

  // Handle toggle tracking
  const handleToggleTracking = () => {
    if (settings?.isTracking) {
      stopTracking();
    } else {
      startTracking();
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-neutral-100">
      {/* Header */}
      <header className="bg-white border-b border-neutral-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <MapPin className="text-primary mr-2" />
            <h1 className="font-semibold text-lg">Location Tracker</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <span className="inline-block h-2 w-2 rounded-full bg-green-500 mr-1"></span>
              <span className="text-sm text-neutral-600">Active</span>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleLogout} 
              disabled={logoutMutation.isPending}
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-auto p-4">
        <StatusCard 
          isTracking={settings?.isTracking ?? false}
          lastUpdated={currentLocation?.timestamp}
          batteryLevel={currentLocation?.batteryLevel}
          isLoading={isLoadingSettings || isLoadingLocation}
          onToggleTracking={handleToggleTracking}
        />

        <LocationMap 
          location={currentLocation}
          isLoading={isLoadingLocation}
          onRefresh={handleRefreshLocation}
        />

        <LocationHistory 
          locations={locationHistory || []}
          isLoading={isLoadingHistory}
          onLoadMore={() => refetchHistory()}
        />
      </main>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-neutral-200">
        <div className="flex justify-around">
          <button 
            className={`flex flex-col items-center py-3 px-5 ${activeTab === "map" ? "text-primary" : "text-neutral-400"}`}
            onClick={() => setActiveTab("map")}
          >
            <span className="material-icons">map</span>
            <span className="text-xs mt-1 font-medium">Map</span>
          </button>
          <button 
            className={`flex flex-col items-center py-3 px-5 ${activeTab === "history" ? "text-primary" : "text-neutral-400"}`}
            onClick={() => setActiveTab("history")}
          >
            <span className="material-icons">history</span>
            <span className="text-xs mt-1">History</span>
          </button>
          <button 
            className={`flex flex-col items-center py-3 px-5 ${activeTab === "settings" ? "text-primary" : "text-neutral-400"}`}
            onClick={() => setActiveTab("settings")}
          >
            <span className="material-icons">settings</span>
            <span className="text-xs mt-1">Settings</span>
          </button>
          <button 
            className={`flex flex-col items-center py-3 px-5 ${activeTab === "profile" ? "text-primary" : "text-neutral-400"}`}
            onClick={() => setActiveTab("profile")}
          >
            <span className="material-icons">person</span>
            <span className="text-xs mt-1">Profile</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
