import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "./queryClient";
import { useToast } from "@/hooks/use-toast";
import { InsertLocation } from "@shared/schema";

export function useLocationService() {
  const { toast } = useToast();

  // Start tracking mutation
  const startTrackingMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/tracking/start", {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Tracking Enabled",
        description: "Location tracking has been started.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error Starting Tracking",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Stop tracking mutation
  const stopTrackingMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/tracking/stop", {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Tracking Paused",
        description: "Location tracking has been paused.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error Stopping Tracking",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update location mutation
  const updateLocationMutation = useMutation({
    mutationFn: async (locationData: InsertLocation) => {
      const res = await apiRequest("POST", "/api/location", locationData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/location/current"] });
      queryClient.invalidateQueries({ queryKey: ["/api/location/history"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Location Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Get current location and send to server
  const getCurrentLocation = async (): Promise<GeolocationPosition | null> => {
    if (!navigator.geolocation) {
      toast({
        title: "Geolocation Not Available",
        description: "Your browser does not support geolocation.",
        variant: "destructive",
      });
      return null;
    }

    try {
      return new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          async (position) => {
            try {
              const battery = await (navigator as any).getBattery?.() || null;
              const batteryLevel = battery ? Math.round(battery.level * 100) : null;

              // Send location to server
              await updateLocationMutation.mutateAsync({
                userId: 0, // This will be set on the server based on authenticated user
                latitude: position.coords.latitude,
                longitude: position.coords.longitude,
                address: '', // Will be resolved on the server if geocoding is available
                batteryLevel,
              });
              
              resolve(position);
            } catch (error) {
              reject(error);
            }
          },
          (error) => {
            reject(new Error(`Geolocation error: ${error.message}`));
          },
          { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
        );
      });
    } catch (error) {
      toast({
        title: "Location Error",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
      return null;
    }
  };

  return {
    startTracking: () => startTrackingMutation.mutate(),
    stopTracking: () => stopTrackingMutation.mutate(),
    updateLocation: updateLocationMutation.mutate,
    getCurrentLocation,
    isUpdatingLocation: updateLocationMutation.isPending,
  };
}
