import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MoreVertical } from "lucide-react";
import { Location } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { formatRelative } from 'date-fns';

interface LocationHistoryProps {
  locations: Location[];
  isLoading: boolean;
  onLoadMore: () => void;
}

export default function LocationHistory({ locations, isLoading, onLoadMore }: LocationHistoryProps) {
  // Format timestamp for display
  const formatTimestamp = (timestamp: Date | string) => {
    const date = typeof timestamp === 'string' ? new Date(timestamp) : timestamp;
    return formatRelative(date, new Date());
  };

  return (
    <Card className="bg-white rounded-lg shadow-sm overflow-hidden">
      <CardHeader className="p-4 border-b border-neutral-200">
        <CardTitle>Location History</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-neutral-200">
          {isLoading ? (
            // Loading skeletons
            Array(3).fill(0).map((_, idx) => (
              <div key={idx} className="p-4">
                <div className="flex justify-between items-start">
                  <div className="w-full">
                    <Skeleton className="h-5 w-3/4 mb-1" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                </div>
              </div>
            ))
          ) : locations.length > 0 ? (
            // Location history items
            locations.map((location) => (
              <div key={location.id} className="p-4 hover:bg-neutral-50">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium">
                      {location.address || `Location at ${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}`}
                    </h3>
                    <p className="text-sm text-neutral-600">
                      {formatTimestamp(location.timestamp)}
                    </p>
                  </div>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))
          ) : (
            // Empty state
            <div className="p-8 text-center">
              <p className="text-muted-foreground">No location history available</p>
            </div>
          )}
          
          {/* Load more button */}
          {locations.length > 0 && (
            <div className="p-4 text-center">
              <Button 
                variant="link" 
                className="text-primary font-medium text-sm"
                onClick={onLoadMore}
              >
                Load More
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
