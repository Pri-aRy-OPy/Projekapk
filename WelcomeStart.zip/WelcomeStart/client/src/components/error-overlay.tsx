import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AlertCircle } from "lucide-react";

interface ErrorOverlayProps {
  title: string;
  message: string;
  onDismiss: () => void;
  onRetry: () => void;
}

export default function ErrorOverlay({ title, message, onDismiss, onRetry }: ErrorOverlayProps) {
  return (
    <AlertDialog defaultOpen={true} open={true}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <div className="flex items-center justify-center mb-4">
            <div className="p-3 rounded-full bg-red-100">
              <AlertCircle className="h-8 w-8 text-red-500" />
            </div>
          </div>
          <AlertDialogTitle className="text-center">{title}</AlertDialogTitle>
          <AlertDialogDescription className="text-center">
            {message}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="flex space-x-3">
          <Button
            variant="outline"
            className="flex-1"
            onClick={onDismiss}
          >
            Dismiss
          </Button>
          <Button
            className="flex-1"
            onClick={onRetry}
          >
            Retry
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
