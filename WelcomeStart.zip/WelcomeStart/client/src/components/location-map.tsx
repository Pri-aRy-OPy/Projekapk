import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Expand, MapPin, RefreshCw } from "lucide-react";
import { Location } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

interface LocationMapProps {
  location?: Location;
  isLoading: boolean;
  onRefresh: () => void;
}

export default function LocationMap({ location, isLoading, onRefresh }: LocationMapProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  // Format coordinates for display
  const formatCoordinate = (coord: number | undefined, suffix: string) => {
    if (coord === undefined) return 'N/A';
    return `${coord.toFixed(6)}° ${suffix}`;
  };

  return (
    <Card className={`bg-white rounded-lg shadow-sm overflow-hidden mb-4 ${isFullscreen ? 'fixed inset-0 z-50' : ''}`}>
      <CardHeader className="p-4 border-b border-neutral-200">
        <CardTitle>Current Location</CardTitle>
      </CardHeader>
      <div className="relative">
        {isLoading ? (
          <Skeleton className="h-64 w-full" />
        ) : (
          <div className="h-64 w-full relative bg-blue-50">
            {/* This would be replaced with an actual map component in production */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center text-gray-500">
                <MapPin className="h-8 w-8 mx-auto mb-2 text-primary animate-pulse" />
                <p>Map View</p>
                <p className="text-xs">
                  Lat: {location?.latitude?.toFixed(6) || 'N/A'}, 
                  Lng: {location?.longitude?.toFixed(6) || 'N/A'}
                </p>
              </div>
            </div>
            <div className="absolute top-0 right-0 m-3 p-2 bg-white rounded-md shadow-md">
              <Button variant="ghost" size="icon" onClick={onRefresh}>
                <RefreshCw className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" onClick={toggleFullscreen}>
                <Expand className="h-4 w-4" />
              </Button>
            </div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="h-5 w-5 rounded-full bg-primary border-2 border-white animate-pulse"></div>
            </div>
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <div className="flex items-center">
          <MapPin className="h-4 w-4 text-neutral-600 mr-2" />
          <span className="text-neutral-800">
            {location?.address || 'Location address not available'}
          </span>
        </div>
        <div className="mt-2 text-sm text-neutral-600">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="block">Latitude</span>
              <span className="font-medium">
                {formatCoordinate(location?.latitude, 'N')}
              </span>
            </div>
            <div>
              <span className="block">Longitude</span>
              <span className="font-medium">
                {formatCoordinate(location?.longitude, 'E')}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
