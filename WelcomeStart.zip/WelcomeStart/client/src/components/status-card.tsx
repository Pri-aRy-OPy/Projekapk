import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from 'date-fns';

interface StatusCardProps {
  isTracking: boolean;
  lastUpdated?: Date | string | null;
  batteryLevel?: number | null;
  isLoading: boolean;
  onToggleTracking: () => void;
}

export default function StatusCard({
  isTracking,
  lastUpdated,
  batteryLevel,
  isLoading,
  onToggleTracking
}: StatusCardProps) {
  // Format the last updated time
  const getFormattedTime = (timestamp?: Date | string | null) => {
    if (!timestamp) return 'Never';
    
    const date = typeof timestamp === 'string' ? new Date(timestamp) : timestamp;
    return formatDistanceToNow(date, { addSuffix: true });
  };

  return (
    <Card className="p-4 mb-4">
      <CardContent className="p-0">
        <h2 className="text-lg font-semibold mb-2">Tracking Status</h2>
        {isLoading ? (
          <>
            <Skeleton className="h-6 w-full mb-2" />
            <div className="mt-3 grid grid-cols-2 gap-4 text-sm">
              <div>
                <Skeleton className="h-4 w-16 mb-1" />
                <Skeleton className="h-5 w-24" />
              </div>
              <div>
                <Skeleton className="h-4 w-16 mb-1" />
                <Skeleton className="h-5 w-16" />
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <span className={`inline-block h-3 w-3 rounded-full ${isTracking ? 'bg-green-500' : 'bg-yellow-500'} mr-2`}></span>
                <span className="text-neutral-600">{isTracking ? 'Active' : 'Paused'}</span>
              </div>
              <Button 
                variant={isTracking ? "destructive" : "default"}
                size="sm"
                onClick={onToggleTracking}
              >
                {isTracking ? 'Pause Tracking' : 'Resume Tracking'}
              </Button>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Last Updated</p>
                <p className="font-medium">{getFormattedTime(lastUpdated)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Battery</p>
                <p className="font-medium">{batteryLevel ? `${batteryLevel}%` : 'N/A'}</p>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
