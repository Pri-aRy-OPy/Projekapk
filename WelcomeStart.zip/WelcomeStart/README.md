
# Aplikasi Tracking

Aplikasi untuk melacak lokasi menggunakan React Native dan Express.js

## Struktur Folder
- `/backend` - API server menggunakan Express.js
- `/mobile` - Aplikasi mobile menggunakan React Native
- `/database` - Schema dan migrasi database

## Cara Menjalankan
1. Install dependencies: `npm install`
2. Setup DATABASE_URL di Secrets
3. Jalankan server: `npm start`
4. Build aplikasi mobile dengan React Native CLI
