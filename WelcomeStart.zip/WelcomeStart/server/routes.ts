import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertLocationSchema, insertSettingsSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication endpoints
  const { requireCreator } = setupAuth(app);

  // LOCATION ENDPOINTS

  // Get current location
  app.get("/api/location/current", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const location = await storage.getLatestLocationByUserId(req.user.id);
      res.json(location);
    } catch (error) {
      next(error);
    }
  });

  // Get location history
  app.get("/api/location/history", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      const locations = await storage.getLocationsByUserId(req.user.id, limit, offset);
      res.json(locations);
    } catch (error) {
      next(error);
    }
  });

  // Create new location
  app.post("/api/location", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Validate request body
      const locationData = insertLocationSchema.parse({
        ...req.body,
        userId: req.user.id, // Override with authenticated user id
      });

      // Check if tracking is enabled
      const settings = await storage.getSettingsByUserId(req.user.id);
      if (settings && !settings.isTracking) {
        return res.status(400).json({ message: "Tracking is currently disabled" });
      }

      const location = await storage.createLocation(locationData);
      res.status(201).json(location);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid location data", errors: error.errors });
      }
      next(error);
    }
  });

  // TRACKING SETTINGS ENDPOINTS

  // Get tracking settings
  app.get("/api/settings", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      let settings = await storage.getSettingsByUserId(req.user.id);
      
      // Create default settings if none exist
      if (!settings) {
        settings = await storage.createSettings({
          userId: req.user.id,
          isTracking: true,
          trackingInterval: 300,
        });
      }
      
      res.json(settings);
    } catch (error) {
      next(error);
    }
  });

  // Update tracking settings
  app.put("/api/settings", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Validate request body
      const settingsData = insertSettingsSchema.parse({
        ...req.body,
        userId: req.user.id,
      });

      const settings = await storage.updateSettingsByUserId(req.user.id, settingsData);
      res.json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid settings data", errors: error.errors });
      }
      next(error);
    }
  });

  // Start tracking
  app.post("/api/tracking/start", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      let settings = await storage.getSettingsByUserId(req.user.id);
      
      // Create or update settings
      if (!settings) {
        settings = await storage.createSettings({
          userId: req.user.id,
          isTracking: true,
          trackingInterval: 300,
        });
      } else {
        settings = await storage.updateSettingsByUserId(req.user.id, {
          ...settings,
          isTracking: true,
        });
      }
      
      res.json(settings);
    } catch (error) {
      next(error);
    }
  });

  // Stop tracking
  app.post("/api/tracking/stop", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      let settings = await storage.getSettingsByUserId(req.user.id);
      
      // Create or update settings
      if (!settings) {
        settings = await storage.createSettings({
          userId: req.user.id,
          isTracking: false,
          trackingInterval: 300,
        });
      } else {
        settings = await storage.updateSettingsByUserId(req.user.id, {
          ...settings,
          isTracking: false,
        });
      }
      
      res.json(settings);
    } catch (error) {
      next(error);
    }
  });

  // ADMIN ENDPOINTS (CREATOR ONLY)

  // Get all users (creator only)
  app.get("/api/admin/users", requireCreator, async (req, res, next) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      next(error);
    }
  });

  // Get locations for any user (creator only)
  app.get("/api/admin/locations/:userId", requireCreator, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.userId);
      const locations = await storage.getLocationsByUserId(userId);
      res.json(locations);
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
