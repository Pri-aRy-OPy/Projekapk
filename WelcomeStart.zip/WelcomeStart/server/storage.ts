import { 
  users, type User, type InsertUser,
  locations, type Location, type InsertLocation,
  settings, type Settings, type InsertSettings
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  setCreatorStatus(id: number, isCreator: boolean): Promise<User | undefined>;
  
  // Location operations
  createLocation(location: InsertLocation): Promise<Location>;
  getLocationsByUserId(userId: number, limit?: number, offset?: number): Promise<Location[]>;
  getLatestLocationByUserId(userId: number): Promise<Location | undefined>;
  
  // Settings operations
  getSettingsByUserId(userId: number): Promise<Settings | undefined>;
  createSettings(settings: InsertSettings): Promise<Settings>;
  updateSettingsByUserId(userId: number, settings: Partial<InsertSettings>): Promise<Settings>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private locations: Map<number, Location>;
  private userSettings: Map<number, Settings>;
  public sessionStore: session.SessionStore;
  
  private userIdCounter: number;
  private locationIdCounter: number;
  private settingsIdCounter: number;

  constructor() {
    this.users = new Map();
    this.locations = new Map();
    this.userSettings = new Map();
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    this.userIdCounter = 1;
    this.locationIdCounter = 1;
    this.settingsIdCounter = 1;
  }

  // USER OPERATIONS

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id, isCreator: false };
    this.users.set(id, user);
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async setCreatorStatus(id: number, isCreator: boolean): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, isCreator };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // LOCATION OPERATIONS

  async createLocation(insertLocation: InsertLocation): Promise<Location> {
    const id = this.locationIdCounter++;
    const timestamp = new Date();
    
    // Build a dummy address if none provided
    let address = insertLocation.address;
    if (!address) {
      address = `Location at ${insertLocation.latitude.toFixed(4)}, ${insertLocation.longitude.toFixed(4)}`;
    }
    
    const location: Location = { 
      ...insertLocation,
      id, 
      timestamp,
      address
    };
    
    this.locations.set(id, location);
    return location;
  }

  async getLocationsByUserId(userId: number, limit = 10, offset = 0): Promise<Location[]> {
    const userLocations = Array.from(this.locations.values())
      .filter(location => location.userId === userId)
      .sort((a, b) => {
        const dateA = new Date(a.timestamp).getTime();
        const dateB = new Date(b.timestamp).getTime();
        return dateB - dateA; // Sort in descending order (newest first)
      });
    
    return userLocations.slice(offset, offset + limit);
  }

  async getLatestLocationByUserId(userId: number): Promise<Location | undefined> {
    const locations = await this.getLocationsByUserId(userId, 1);
    return locations.length > 0 ? locations[0] : undefined;
  }

  // SETTINGS OPERATIONS

  async getSettingsByUserId(userId: number): Promise<Settings | undefined> {
    // Find settings by user ID
    return Array.from(this.userSettings.values()).find(
      (settings) => settings.userId === userId
    );
  }

  async createSettings(insertSettings: InsertSettings): Promise<Settings> {
    const id = this.settingsIdCounter++;
    const settings: Settings = { ...insertSettings, id };
    this.userSettings.set(id, settings);
    return settings;
  }

  async updateSettingsByUserId(userId: number, partialSettings: Partial<InsertSettings>): Promise<Settings> {
    // Find existing settings
    const existingSettings = await this.getSettingsByUserId(userId);
    
    if (existingSettings) {
      // Update existing settings
      const updatedSettings: Settings = { 
        ...existingSettings, 
        ...partialSettings,
        userId // Ensure userId doesn't change
      };
      this.userSettings.set(existingSettings.id, updatedSettings);
      return updatedSettings;
    } else {
      // Create new settings if not found
      return this.createSettings({
        userId,
        isTracking: partialSettings.isTracking ?? true,
        trackingInterval: partialSettings.trackingInterval ?? 300
      });
    }
  }
}

export const storage = new MemStorage();
